package meiit.toth;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class IrTA {

	public static void main(String[] args) throws IOException {
		System.out.println("Adja meg a menyis�get: ");
		Scanner sc = new Scanner(System.in);
		int db = sc.nextInt();
		
		
		FileWriter ir_file = new FileWriter("toth.txt", true);
		BufferedWriter bw = new BufferedWriter(ir_file);
		
		
		
		for(int i = 0; i < db; i++) {
			System.out.println("\nAdja meg a " + (i+1) + ". adatot: ");
			String szam = 	ir();		
			bw.write(szam);
			bw.newLine();			
		}
		bw.close();
		
		System.out.println("\nAdatok sz�ma = " + db + " (�j adat)");
		int i = 0;
		try {
			FileReader reader = new FileReader("toth.txt");
			BufferedReader br = new BufferedReader(reader);
			
			String line;
			
			while ((line = br.readLine()) != null) {
				System.out.println(i + ". adat = " + line);	
				i++;
			}
		}catch (IOException e) {
			e.printStackTrace();
		}
		
		System.out.println("\nAdatok sz�ma = " + i);
	}
	
	public static String ir() throws IOException{
		String sz;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		sz = br.readLine();
		
		return sz;
	}
	
}
